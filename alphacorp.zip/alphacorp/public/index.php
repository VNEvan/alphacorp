<?php
/*
  index.php
---------------------------------------------------------------
  le routeur FRONTAL
 */
include '../app/bootstrap.php';