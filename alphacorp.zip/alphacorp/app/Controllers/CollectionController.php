<?php
namespace App\Controllers;

use App\Models\Collection;
use App\Models\CollectionImages;

class CollectionController extends Controller {

	public function index()
	{
		isLogin();
		$this->display(
			'backoffice/collection/list.html.twig',
			[
				'collections' => Collection::getInstance()->getAll()
			]
		);
	}

	public function add()
	{
		
		$this->display(
			'backoffice/collection/add.html.twig'
		);
	}

	public function edit( $id )
	{

		$this->display(
			'backoffice/collection/edit.html.twig',
			[
				'collections' => Collection::getInstance()->getDetailled( $id ),
			]
		);
	}

	public function save()
	{
		Collection::getInstance()->add( $_POST );
		redirect('/backoffice/collections');
	}

	public function update($id)
	{
		Collection::getInstance()->update( $id, $_POST );
		redirect('/backoffice/collections');
	}

	public function delete($id)
	{
		isLogin();
		Collection::getInstance()->delete( $id );
		redirect('/backoffice/collections');
	}

	public function deleteImg($id)
	{
		isLogin();
		CollectionImages::getInstance()->delete( $id );
		CollectionImages::getInstance()->deleteFile($_GET['filename']);
	}

	public function addImg($id)
	{
		isLogin();
		CollectionImages::getInstance()->addImg( $id );
		redirect('/backoffice/collections/edit/' . $id);
	}



}
