<?php
namespace App\Controllers;

use App\Models\Admin;

class AdminController extends Controller {

	public function index($command = 'index')
	{
				isLogin();
				$this->display(
				'backoffice/admin/admin.html.twig',
				[
					'admins' =>Admin::getInstance()->getAll()
				]
			);
		
	}

/**
 * Login dans l'application BackOffice.
 */
	public function login()
	{
			isLogin();
			redirect('/backoffice');
		
			$this->display(
				'backoffice/login.html.twig'
			);
		

	}



/**
 * Delog de l'application BackOffice.
 */
	public function delog()
	{

	}


}