<?php
namespace App\Controllers;

use App\Models\Classroom;
use App\Models\Children;

class CollectionClassroom extends Controller {

	public function index()
	{
		isLogin();
		$this->display(
			'backoffice/classroom/list.html.twig',
			[
				'classrooms' => Classroom::getInstance()->getAll()
			]
		);
	}


	public function add()
	{
		
		$this->display(
			'backoffice/classroom/add.html.twig'
		);
	}

	public function edit($code)
	{
		
		$this->display(
			'backoffice/classroom/edit.html.twig',
			[
				'classroom' => Classroom::getInstance()->get( $code ),
				'childrens' => Children::getInstance()->getChildrens( Classroom::getInstance()->getIdFromCode( $code ) ),
			]
		);  
	}

	public function update($code) {
		Classroom::getInstance()->update($_POST["id"], arrayExclude($_POST, ["id"]));
		redirect('/backoffice/classroom/');
	}

	public function delete($id)
	{
		
		Classroom::getInstance()->delete($id);
	}

	public function deleteChildren($id)
	{
		isLogin();
		Children::getInstance()->delete( $id );
	}


		public function addChildren( $idclasse )
	{
		isLogin();
		Children::getInstance()->addChildren( $idclasse );
		redirect("/backoffice/classroom/edit/" . $_POST["classroom_code"] );
	}


	public function save()
	{
		Classroom::getInstance()->add( $_POST );
		redirect('/backoffice/classroom/');
	}

	public function code()
	{
		$code = Classroom::getInstance()->generateCode();
		echo $code;
	}


}
