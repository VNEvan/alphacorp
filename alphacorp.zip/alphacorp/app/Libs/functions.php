<?php

/**
Redirige vers une commande.
@param  string  la commande.
 */
function redirect($url) {

	header('Location: ' . ROOT_URL . $url);
}

/**
Retourne l'URL vers une commande.
@param  string  la commande.
 */
function url($url = '') {

	echo ROOT_URL . $url;
}


/**
 * Vérifie que l'utilisateur est connecté
 * @param  boolean $redirect Détermine si la fonction doit rediriger le client ou si la fonction retourbe un booléen
 * @return redirection ou boolean           Valeur de isset($_SESSION['login'])
 */
function isLogin( $redirect = true ) {
	if ( $redirect ) {
			if( !isset( $_SESSION['login'] )) {
				redirect('/login');
			}
	} else {
			return isset( $_SESSION['login'] );
	}
}

function getRandomString($length = 6) {
	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$string = '';

	for ($i = 0; $i < $length; $i++) {
		$string .= $characters[mt_rand(0, strlen($characters) - 1)];
	}

	return $string;
}


  function to_camel_case( $str, array $noStrip = [] )
  {
    $str = trim( mb_strtolower( $str,'UTF-8') );
    $str = ucwords($str);
    $str = str_replace(" ", "", $str);
    $str = lcfirst($str);
    return $str;
  }

  function arrayExclude($array, array $excludeKeys)
  {
  	foreach($array as $key => $value)
  	{
  		if(!in_array($key, $excludeKeys))
  		{
  			$return[$key] = $value;
  		}
  	}
  	return $return;
  }