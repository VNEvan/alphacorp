<?php

///////////////////////
//ACCUEIL DU SITE WEB//
///////////////////////
$route->addRoute('GET', '/', 'HomeController@index');


// interface enseignant
$route->addRoute('GET', '/classe/{code}/config', 'HomeController@config');
$route->addRoute('GET', '/classe/{code}/defi', 'HomeController@defi');

$route->addRoute('GET', '/classe/{code}/childrens', 'HomeController@childrens');
$route->addRoute('GET', '/classe/{code}/config/defi', 'HomeController@deficonf');

// interface enfant
$route->addRoute('GET', '/jouer/{idchildren}/{idchallenge}', 'HomeController@jouer');

///////////////
//BACKOFFICE //
///////////////

// MENU PRINCIPAL BACKOFFICE
$route->addRoute('GET', '/backoffice', 'BoController@index');

// LISTE DES ADMINS
$route->addRoute('GET', '/backoffice/admins', 'AdminController@index');

// LISTE DES DEFIS
$route->addRoute('GET', '/backoffice/challenges', 'ChallengeController@index');

//	RAJOUTER UN DEFI
$route->addRoute('GET', '/backoffice/challenges/add', 'ChallengeController@add');

// ENREGISTRER UN NOUVEAU DEFI
$route->addRoute('POST', '/backoffice/challenges/save', 'ChallengeController@save');

// EDITION D'UN DEFI
$route->addRoute('GET', '/backoffice/challenges/edit/{id:[0-9]+}', 'ChallengeController@edit');

// ENREGISTREMENT MODIFICATIONS D'UN DEFI
$route->addRoute('POST', '/backoffice/challenges/edit/{id:[0-9]+}', 'ChallengeController@update');

// SUPPRESSION D'UN DEFI
$route->addRoute('GET', '/backoffice/challenges/delete/{id:[0-9]+}', 'ChallengeController@delete');

///////////////
//COLLECTION //
///////////////

// MENU PRINCIPALE DES COLLECTIONS
$route->addRoute('GET', '/backoffice/collections', 'CollectionController@index');

// AJOUTER UNE COLLECTION
$route->addRoute('GET', '/backoffice/collections/add', 'CollectionController@add');

// ENREGISTRER UNE NOUVELLE COLLECTION
$route->addRoute('POST', '/backoffice/collections/save', 'CollectionController@save');

// MODIFICATION D'UNE COLLECTION
$route->addRoute('GET', '/backoffice/collections/edit/{id:[0-9]+}', 'CollectionController@edit');

// SAUVRAGERDER LES MODIFICATIONS D'UNE COLLECTION
$route->addRoute('POST', '/backoffice/collections/edit/{id:[0-9]+}', 'CollectionController@update');

// SUPPRIMER UNE COLLECTION
$route->addRoute('GET', '/backoffice/collections/delete/{id:[0-9]+}', 'CollectionController@delete');

// SUPPRIMER UNE IMAGE D'UNE COLLECTION
$route->addRoute('GET', '/backoffice/collections/images/delete/{id:[0-9]+}', 'CollectionController@deleteImg');

// AJOUTER UNE IMAGE A UNE COLLECTION
$route->addRoute('POST', '/backoffice/collections/add-letter/{id:[0-9]+}', 'CollectionController@addImg');


//////////////
//CLASSROMM //
//////////////

// MENU PRINCIPALE DES CLASSES
$route->addRoute('GET', '/backoffice/classroom', 'CollectionClassroom@index');

// AJOUTER UNE CLASSE
$route->addRoute('GET', '/backoffice/classroom/add', 'CollectionClassroom@add');

// ENRIGSTRER UNE NOUVELLE CLASSE
$route->addRoute('POST', '/backoffice/classroom/save', 'CollectionClassroom@save');

// MODIFIER UNE CLASSE
$route->addRoute('GET', '/backoffice/classroom/edit/{code:[A-Za-z0-9]+}', 'CollectionClassroom@edit');

// ENREGISTRER LES MODIFICATIONS D'UNE CLASSE  
$route->addRoute('POST', '/backoffice/classroom/edit/{code:[A-Za-z0-9]+}', 'CollectionClassroom@update');

// SUPPRIMER UNE CLASSE
$route->addRoute('GET', '/backoffice/classroom/delete/{id}', 'CollectionClassroom@delete');

// SUPPRIMER UN ENFANT 
$route->addRoute('GET', '/backoffice/classroom/children/delete/{id:[0-9]+}', 'CollectionClassroom@deleteChildren');

// AJOUTER UN ENFANT 
$route->addRoute('POST', '/backoffice/classroom/add-children/{id:[0-9]+}', 'CollectionClassroom@addChildren');


///////////////////////
//PROCESSUS DE LOGIN //
///////////////////////


$route->addRoute('GET', '/login', 'BoController@login');
$route->addRoute('POST', '/login', 'BoController@loginCheck');
$route->addRoute('GET', '/delog', 'BoController@delog');

