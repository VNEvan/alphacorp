<?php

/**
 * FICHIER : app / Models / Children.php
 */

namespace App\Models;

class Collection extends Base {

	protected $tableName = TABLE_PREFIX . 'collection';

	private static $instance;

	public static function getInstance()
  {
		if (!isset(self::$instance)) {
			self::$instance = new Collection();
		}
		return self::$instance;
	}

	public function getDetailled( $idcollection )
  {
    $sql = "SELECT * FROM {$this->tableName} WHERE id = :id";
    $sth = self::$dbh->prepare( $sql );
    $datas =  $sth->execute( [':id' => $idcollection] );
    $datas = $sth->fetch();
    $datas[ 'images' ] = CollectionImages::getInstance()->getFromCollection( $idcollection );
    return $datas;
  }
	
}