<?php

/**
 * FICHIER : app / Models / Children.php
 */

namespace App\Models;

class CollectionImages extends Base {
	protected $tableName = TABLE_PREFIX . 'collection_image';

	private static $instance;

	public static function getInstance()
  {
		if (!isset(self::$instance)) {
			self::$instance = new CollectionImages();
		}
		return self::$instance;
	}

	/**
   * Retourne les informations détaillées sur une collection d'images.
   * @param  integer  $idcollection   identifiant de la collection d'images
   * @return array (id, letter, image, collection_id, createdAt )
   */

	public function getFromCollection( $idcollection )
	{
	$sql = "SELECT *
	 FROM {$this->tableName}
	 WHERE collection_id = $idcollection";
	return self::$dbh->query($sql)->fetchAll();
	}

	public function addImg( $idcollection )
	{
		$uploaddir = ASSETS_PATH . 'img' . DS . 'abécédaire' . DS;
		$uploadfile = $uploaddir . basename($_FILES['image']['name']);

		if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile)) {

	    $sql = "INSERT INTO $this->tableName (letter, image, collection_id) VALUES (:letter, :image, :collection_id)";
			$sth = self::$dbh->prepare($sql);
			$sth->execute([
				':letter' => $_POST["letter"],
				':image' => $_FILES['image']['name'],
				':collection_id' => $idcollection,
			]);

		}
	}

		public function deleteFile( $filename )  {
			unlink($filename);
		}

}