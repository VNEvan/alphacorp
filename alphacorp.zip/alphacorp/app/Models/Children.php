<?php

/**
 * FICHIER : app / Models / Children.php
 */

namespace App\Models;

class Children extends Base {
	protected $tableName = TABLE_PREFIX . 'children';
	protected $tableClassroom = TABLE_PREFIX . 'classroom';

	private static $instance;

	public static function getInstance()
  {
		if (!isset(self::$instance)) {
			self::$instance = new Children();
		}
		return self::$instance;
	}
	/**
	* Retourne les informations sur tous les enfants ainsi que
	 * le nom de la classe associé et le pseudo de l'enseignant associé.
	*/

	public function getAll()
	{
	$sql = "SELECT t1.id, t1.pseudo, t1.avatar, t1.classroom_id, t1.createdAt, t2.teachername, t2.description FROM {$this->tableName} t1, {$this->tableClassroom} t2";
	return self::$dbh->query( $sql)->fetchAll();
	}

	public function getChildrens( $classroom_id ) {
		$sql = "SELECT * FROM {$this->tableName} WHERE classroom_id = :classroom_id";
    $sth = self::$dbh->prepare($sql);
    $sth->bindValue(':classroom_id', $classroom_id );
    $sth->execute();
    return $sth->fetchAll();
	}

	public function addChildren( $idclasse )
	{
		$uploaddir = ASSETS_PATH . 'img' . DS . 'avatar' . DS;
		$uploadfile = $uploaddir . basename($_FILES['avatar']['name']);

		if (move_uploaded_file($_FILES['avatar']['tmp_name'], $uploadfile)) {

	    $sql = "INSERT INTO $this->tableName (pseudo, avatar, classroom_id) VALUES (:pseudo, :avatar, :classroom_id)";
			$sth = self::$dbh->prepare($sql);
			$sth->execute([
				':pseudo' => $_POST["pseudo"],
				':avatar' => $_FILES['avatar']['name'],
				':classroom_id' => $idclasse
			]);

		}
	}
}