<?php

/* backoffice/deficonf.html.twig */
class __TwigTemplate_4db0bb06e8df46cc5f7c019138b22bb939fa89a4b11f72cb9c09db2c208f0344 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("backoffice/template.html.twig", "backoffice/deficonf.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "backoffice/template.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "BackOffice | les défis";
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "
<h1>Les défis</h1>
<p>Selectionnez les défis que vous allez présenter aux enfants de votre classe.</p>
<table class=\"table mt-2\">
  <thead class=\"thead-light\">

  </thead>
  <tbody>
  ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["challenges"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["challenge"]) {
            // line 13
            echo "    <tr>
    \t<td><input type =\"checkbox\" name=\"defi_";
            // line 14
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["challenge"], "id", array()), "html", null, true);
            echo "\" >  ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["challenge"], "code", array()), "html", null, true);
            echo "</td>
      <td>";
            // line 15
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["challenge"], "description", array()), "html", null, true);
            echo "</td>
      
    </tr>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['challenge'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "</tbody>
</table>
<a href=\"";
        // line 21
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array("/backoffice/challenges/#")), "html", null, true);
        echo "\" class=\"btn btn-primary\">Enregistrer</a>

<a href=\"";
        // line 23
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array((("/classe/" . twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["session"] ?? null), "classroom", array()), "code", array())) . "/config"))), "html", null, true);
        echo "\">Annuler</a>


";
    }

    public function getTemplateName()
    {
        return "backoffice/deficonf.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 23,  79 => 21,  75 => 19,  65 => 15,  59 => 14,  56 => 13,  52 => 12,  42 => 4,  39 => 3,  33 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"backoffice/template.html.twig\" %}
{% block title %}BackOffice | les défis{% endblock %}
{% block content %}

<h1>Les défis</h1>
<p>Selectionnez les défis que vous allez présenter aux enfants de votre classe.</p>
<table class=\"table mt-2\">
  <thead class=\"thead-light\">

  </thead>
  <tbody>
  {% for challenge in challenges %}
    <tr>
    \t<td><input type =\"checkbox\" name=\"defi_{{challenge.id}}\" >  {{ challenge.code }}</td>
      <td>{{ challenge.description }}</td>
      
    </tr>
{% endfor %}
</tbody>
</table>
<a href=\"{{ url( '/backoffice/challenges/#' )}}\" class=\"btn btn-primary\">Enregistrer</a>

<a href=\"{{ url( '/classe/' ~ session.classroom.code ~ '/config' )}}\">Annuler</a>


{% endblock %}", "backoffice/deficonf.html.twig", "I:\\UwAmp-www\\alphacorp\\app\\Views\\backoffice\\deficonf.html.twig");
    }
}
