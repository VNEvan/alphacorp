<?php

/* backoffice/collection/list.html.twig */
class __TwigTemplate_9d216ab57ac23304155c9e14eee381db54831553c5c64739ff6f1c5f044d3894 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("backoffice/template.html.twig", "backoffice/collection/list.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'specific_js' => array($this, 'block_specific_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "backoffice/template.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "BackOffice | les collections";
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "
<h1>Les collections</h1>
<p>Voici la liste des <b>collections</b> déjà existantes dans l'application.</p>
<a href=\"";
        // line 7
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array("/backoffice/collections/add")), "html", null, true);
        echo "\" class=\"btn btn-primary\">Ajouter une autre collection</a>
<table class=\"table mt-2\">
  <thead class=\"thead-light\">
    <tr>
      <th scope=\"col\">#</th>
      <th scope=\"col\">Nom</th>
      <th scope=\"col\"></th>
    </tr>
  </thead>
  <tbody>
  ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["collections"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["collection"]) {
            // line 18
            echo "    <tr>
      <th scope=\"row\">";
            // line 19
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["collection"], "id", array()), "html", null, true);
            echo "</th>
      <td>";
            // line 20
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["collection"], "name", array()), "html", null, true);
            echo "</td>
      <td>
        <a class=\"btn btn-link\" href=\"";
            // line 22
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array(("/backoffice/collections/edit/" . twig_get_attribute($this->env, $this->source, $context["collection"], "id", array())))), "html", null, true);
            echo "\">éditer</a>
        <button class=\"btn btn-link delete-collection\" data-href=\"";
            // line 23
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array(("/backoffice/collections/delete/" . twig_get_attribute($this->env, $this->source, $context["collection"], "id", array())))), "html", null, true);
            echo "\"  data-toggle=\"modal\" data-target=\"#exampleModal\">supprimer</button>
      </td>
    </tr>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['collection'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "  </tbody>
</table>
  <!-- Modal -->
  <div class=\"modal fade\" id=\"exampleModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
    <div class=\"modal-dialog\" role=\"document\">
      <div class=\"modal-content\">
        <div class=\"modal-header\">
          <h5 class=\"modal-title\" id=\"exampleModalLabel\">Suppression d'une collection</h5>
          <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
            <span aria-hidden=\"true\">&times;</span>
          </button>
        </div>
        <div class=\"modal-body\">
          Souhaitez-vous réellement supprimer cette collection ?
        </div>
        <div class=\"modal-footer\">
          <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Annuler</button>
          <button id=\"confirm-delete\" class=\"btn btn-danger\" data-dismiss=\"modal\">Supprimer</button>
        </div>
      </div>
    </div>
  </div>

";
    }

    // line 51
    public function block_specific_js($context, array $blocks = array())
    {
        // line 52
        echo "\t<script>
\t\tvar link = null,
\t\t\t\tid = null,
\t\t\t\tbalise = null;
\t\t\$(\".delete-collection\").click( function() {
\t\t\tbalise = \$(this).parent().parent();
\t\t\tid = \$(this).parent().siblings('th').val();
\t\t\tlink = \$(this).data('href');
\t\t\tconsole.log(link);
\t\t});
\t\t\$(\"#confirm-delete\").click( function() {
\t\t\t\tconsole.log(link);
\t\t\t\t\$.get(link);
\t\t\t\tbalise.remove();
\t\t});
\t</script>
";
    }

    public function getTemplateName()
    {
        return "backoffice/collection/list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 52,  118 => 51,  91 => 27,  81 => 23,  77 => 22,  72 => 20,  68 => 19,  65 => 18,  61 => 17,  48 => 7,  43 => 4,  40 => 3,  34 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"backoffice/template.html.twig\" %}
{% block title %}BackOffice | les collections{% endblock %}
{% block content %}

<h1>Les collections</h1>
<p>Voici la liste des <b>collections</b> déjà existantes dans l'application.</p>
<a href=\"{{ url( '/backoffice/collections/add' )}}\" class=\"btn btn-primary\">Ajouter une autre collection</a>
<table class=\"table mt-2\">
  <thead class=\"thead-light\">
    <tr>
      <th scope=\"col\">#</th>
      <th scope=\"col\">Nom</th>
      <th scope=\"col\"></th>
    </tr>
  </thead>
  <tbody>
  {% for collection in collections %}
    <tr>
      <th scope=\"row\">{{ collection.id }}</th>
      <td>{{ collection.name }}</td>
      <td>
        <a class=\"btn btn-link\" href=\"{{ url( '/backoffice/collections/edit/' ~ collection.id ) }}\">éditer</a>
        <button class=\"btn btn-link delete-collection\" data-href=\"{{ url( '/backoffice/collections/delete/' ~ collection.id )}}\"  data-toggle=\"modal\" data-target=\"#exampleModal\">supprimer</button>
      </td>
    </tr>
{% endfor %}
  </tbody>
</table>
  <!-- Modal -->
  <div class=\"modal fade\" id=\"exampleModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
    <div class=\"modal-dialog\" role=\"document\">
      <div class=\"modal-content\">
        <div class=\"modal-header\">
          <h5 class=\"modal-title\" id=\"exampleModalLabel\">Suppression d'une collection</h5>
          <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
            <span aria-hidden=\"true\">&times;</span>
          </button>
        </div>
        <div class=\"modal-body\">
          Souhaitez-vous réellement supprimer cette collection ?
        </div>
        <div class=\"modal-footer\">
          <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Annuler</button>
          <button id=\"confirm-delete\" class=\"btn btn-danger\" data-dismiss=\"modal\">Supprimer</button>
        </div>
      </div>
    </div>
  </div>

{% endblock %}
{% block specific_js %}
\t<script>
\t\tvar link = null,
\t\t\t\tid = null,
\t\t\t\tbalise = null;
\t\t\$(\".delete-collection\").click( function() {
\t\t\tbalise = \$(this).parent().parent();
\t\t\tid = \$(this).parent().siblings('th').val();
\t\t\tlink = \$(this).data('href');
\t\t\tconsole.log(link);
\t\t});
\t\t\$(\"#confirm-delete\").click( function() {
\t\t\t\tconsole.log(link);
\t\t\t\t\$.get(link);
\t\t\t\tbalise.remove();
\t\t});
\t</script>
{% endblock %}", "backoffice/collection/list.html.twig", "I:\\UwAmp-www\\alphacorp\\app\\Views\\backoffice\\collection\\list.html.twig");
    }
}
