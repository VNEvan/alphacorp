<?php

/* defi.html.twig */
class __TwigTemplate_53e2227868ade19ab8df414bda1f5273b76bc8868fb16dd8703c0c17b55f2e44 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "defi.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'additional_css' => array($this, 'block_additional_css'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Défis";
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "
  <div class=\"container\">
    <h1>Alphacorp > accueil</h1>
    <p class=\"description\">
      Démarre le jeu en utilisant ton pseudo et choisi ton défi.
    </p>
\t\t<!-- Faire boucle en twig pour afficher le nom des défis et leurs descriptions -->
  </div>
";
    }

    // line 13
    public function block_additional_css($context, array $blocks = array())
    {
        // line 14
        echo "<style>
html {
  font-size: 22px
}
</style>
";
    }

    public function getTemplateName()
    {
        return "defi.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 14,  55 => 13,  43 => 4,  40 => 3,  34 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}
{% block title %}Défis{% endblock %}
{% block content %}

  <div class=\"container\">
    <h1>Alphacorp > accueil</h1>
    <p class=\"description\">
      Démarre le jeu en utilisant ton pseudo et choisi ton défi.
    </p>
\t\t<!-- Faire boucle en twig pour afficher le nom des défis et leurs descriptions -->
  </div>
{% endblock %}
{% block additional_css %}
<style>
html {
  font-size: 22px
}
</style>
{% endblock %}", "defi.html.twig", "I:\\UwAmp-www\\alphacorp\\app\\Views\\defi.html.twig");
    }
}
