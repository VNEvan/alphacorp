<?php

/* children.html.twig */
class __TwigTemplate_bcc0b1fc5d6e2b4a1ce9b0576605c4badf41461bfde9daa17c28ed9a5a191ac4 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 2
        $this->parent = $this->loadTemplate("layout.html.twig", "children.html.twig", 2);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "<div class=\"row\">
  ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["childrens"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["children"]) {
            // line 6
            echo "  <div class=\"p-4 col-2 border d-flex flex-column justify-content-between align-items-center\">
    <div class=\"row\">
      <img class=\"w-100 mh-100\" src=\"";
            // line 8
            echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('url')->getCallable(), array("/assets/img/avatar/")) . twig_get_attribute($this->env, $this->source, $context["children"], "avatar", array())), "html", null, true);
            echo "\"/>
    </div>
    <p class=\"text-uppercase font-weight-bold\">";
            // line 10
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["children"], "pseudo", array()), "html", null, true);
            echo "</p>
    <button type=\"button\" class=\"btn btn-primary delete-children\" data-id=\"";
            // line 11
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["children"], "id", array()), "html", null, true);
            echo "\" data-href=\"";
            echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('url')->getCallable(), array("/backoffice/classroom/children/delete/")) . twig_get_attribute($this->env, $this->source, $context["children"], "id", array())), "html", null, true);
            echo "\">Effacer</button>
  </div>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['children'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "children.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  66 => 14,  55 => 11,  51 => 10,  46 => 8,  42 => 6,  38 => 5,  35 => 4,  32 => 3,  15 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% extends \"layout.html.twig\" %}
{% block content %}
<div class=\"row\">
  {% for children in childrens %}
  <div class=\"p-4 col-2 border d-flex flex-column justify-content-between align-items-center\">
    <div class=\"row\">
      <img class=\"w-100 mh-100\" src=\"{{ url('/assets/img/avatar/') ~ children.avatar }}\"/>
    </div>
    <p class=\"text-uppercase font-weight-bold\">{{ children.pseudo }}</p>
    <button type=\"button\" class=\"btn btn-primary delete-children\" data-id=\"{{ children.id }}\" data-href=\"{{ url('/backoffice/classroom/children/delete/') ~ children.id }}\">Effacer</button>
  </div>
  {% endfor %}
</div>
{% endblock %}", "children.html.twig", "I:\\UwAmp-www\\alphacorp\\app\\Views\\children.html.twig");
    }
}
