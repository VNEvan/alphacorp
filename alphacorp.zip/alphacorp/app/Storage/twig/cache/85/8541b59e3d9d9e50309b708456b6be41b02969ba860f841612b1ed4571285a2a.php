<?php

/* backoffice/classroom/list.html.twig */
class __TwigTemplate_752e4ad77febf13a9a028ff3574697dc93cfb79a63406bb9afd1ac70e9c18ce5 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("backoffice/template.html.twig", "backoffice/classroom/list.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'specific_js' => array($this, 'block_specific_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "backoffice/template.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "BackOffice | les classes";
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "
<h1>Les défis</h1>
<p>Voici la liste des <b>classes</b> déjà existants dans l'application.</p>
<a href=\"";
        // line 7
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array("/backoffice/classroom/add")), "html", null, true);
        echo "\" class=\"btn btn-primary\">Ajouter une nouvelle classe</a>
<table class=\"table mt-2\">
  <thead class=\"thead-light\">
    <tr>
      <th scope=\"col\">#</th>
      <th scope=\"col\">Description</th>
      <th scope=\"col\">Enseignant</th>
      <th scope=\"col\">Code</th>
      <th scope=\"col\">Création</th>
      <th scope=\"col\"></th>
    </tr>
  </thead>
  <tbody>
  ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["classrooms"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["classroom"]) {
            // line 21
            echo "    <tr>
      <th scope=\"row\">";
            // line 22
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["classroom"], "id", array()), "html", null, true);
            echo "</th>
      <td>";
            // line 23
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["classroom"], "description", array()), "html", null, true);
            echo "</td>
      <td>";
            // line 24
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["classroom"], "teachername", array()), "html", null, true);
            echo "</td>
      <td>";
            // line 25
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["classroom"], "code", array()), "html", null, true);
            echo "</td>
      <td>";
            // line 26
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["classroom"], "createdAt", array()), "html", null, true);
            echo "</td>
      <td>
        <a class=\"btn btn-link\" href=\"";
            // line 28
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array(("/backoffice/classroom/edit/" . twig_get_attribute($this->env, $this->source, $context["classroom"], "code", array())))), "html", null, true);
            echo "\">éditer</a>
        <button class=\"btn btn-link deleteButton\" data-href=\"";
            // line 29
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array(("/backoffice/classroom/delete/" . twig_get_attribute($this->env, $this->source, $context["classroom"], "id", array())))), "html", null, true);
            echo "\">supprimer</button>
      </td>
    </tr>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['classroom'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "
";
    }

    // line 35
    public function block_specific_js($context, array $blocks = array())
    {
        // line 36
        echo "<script>
  \$('.deleteButton').click( function() {
    var url = \$(this).data('href');
    \$this = \$(this);
    \$.get( url , function() {
      \$this.parent().parent().remove();
    } );
  });
  
</script>

";
    }

    public function getTemplateName()
    {
        return "backoffice/classroom/list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 36,  111 => 35,  106 => 33,  96 => 29,  92 => 28,  87 => 26,  83 => 25,  79 => 24,  75 => 23,  71 => 22,  68 => 21,  64 => 20,  48 => 7,  43 => 4,  40 => 3,  34 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"backoffice/template.html.twig\" %}
{% block title %}BackOffice | les classes{% endblock %}
{% block content %}

<h1>Les défis</h1>
<p>Voici la liste des <b>classes</b> déjà existants dans l'application.</p>
<a href=\"{{ url( '/backoffice/classroom/add' )}}\" class=\"btn btn-primary\">Ajouter une nouvelle classe</a>
<table class=\"table mt-2\">
  <thead class=\"thead-light\">
    <tr>
      <th scope=\"col\">#</th>
      <th scope=\"col\">Description</th>
      <th scope=\"col\">Enseignant</th>
      <th scope=\"col\">Code</th>
      <th scope=\"col\">Création</th>
      <th scope=\"col\"></th>
    </tr>
  </thead>
  <tbody>
  {% for classroom in classrooms %}
    <tr>
      <th scope=\"row\">{{ classroom.id }}</th>
      <td>{{ classroom.description }}</td>
      <td>{{ classroom.teachername }}</td>
      <td>{{ classroom.code }}</td>
      <td>{{ classroom.createdAt }}</td>
      <td>
        <a class=\"btn btn-link\" href=\"{{ url( '/backoffice/classroom/edit/' ~ classroom.code )}}\">éditer</a>
        <button class=\"btn btn-link deleteButton\" data-href=\"{{ url( '/backoffice/classroom/delete/' ~ classroom.id )}}\">supprimer</button>
      </td>
    </tr>
{% endfor %}

{% endblock %}
{% block specific_js %}
<script>
  \$('.deleteButton').click( function() {
    var url = \$(this).data('href');
    \$this = \$(this);
    \$.get( url , function() {
      \$this.parent().parent().remove();
    } );
  });
  
</script>

{% endblock %}", "backoffice/classroom/list.html.twig", "I:\\UwAmp-www\\alphacorp\\app\\Views\\backoffice\\classroom\\list.html.twig");
    }
}
