<?php

/* backoffice/login.html.twig */
class __TwigTemplate_b0ac1a06ac74503c334b1c49bf62b63d7b142de70ff381874666134bdda66ee1 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "backoffice/login.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        echo "<form method=\"POST\" action=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array("/login")), "html", null, true);
        echo "\">
\t<div class=\"row\">
\t\t<div class=\"col-3\">
\t\t\t<input class=\"form-control\" type=\"text\" name=\"name\" placeholder=\"Nom d'utilisateur\" />
\t\t</div>
\t</div>
\t<div class=\"row mt-3\">
\t\t<div class=\"col-3\">
\t\t\t<input class=\"form-control\" type=\"password\" name=\"password\" placeholder=\"Mot de passe\"/>
\t\t</div>
\t</div>
\t<button class=\"btn btn-primary mt-3\">Valider</button>
</form>
";
    }

    public function getTemplateName()
    {
        return "backoffice/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  35 => 3,  32 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}
{% block content %}
<form method=\"POST\" action=\"{{ url('/login') }}\">
\t<div class=\"row\">
\t\t<div class=\"col-3\">
\t\t\t<input class=\"form-control\" type=\"text\" name=\"name\" placeholder=\"Nom d'utilisateur\" />
\t\t</div>
\t</div>
\t<div class=\"row mt-3\">
\t\t<div class=\"col-3\">
\t\t\t<input class=\"form-control\" type=\"password\" name=\"password\" placeholder=\"Mot de passe\"/>
\t\t</div>
\t</div>
\t<button class=\"btn btn-primary mt-3\">Valider</button>
</form>
{% endblock %}", "backoffice/login.html.twig", "I:\\UwAmp-www\\alphacorp\\alphacorp\\app\\Views\\backoffice\\login.html.twig");
    }
}
