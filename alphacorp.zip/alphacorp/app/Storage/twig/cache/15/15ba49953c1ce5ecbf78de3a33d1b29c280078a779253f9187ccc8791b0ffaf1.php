<?php

/* backoffice/children.html.twig */
class __TwigTemplate_a28903828c7d29908b165e7a368f2db1d25258d7ac28f7184177e667811ab883 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 2
        $this->parent = $this->loadTemplate("backoffice/template.html.twig", "backoffice/children.html.twig", 2);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "backoffice/template.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t<h1>Les défis</h1>
\t\t\t<p>Voici la liste des <b>classes</b> déjà existants dans l'application.</p>
\t\t\t<a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('url')->getCallable(), array(("/classe/" . twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["session"] ?? null), "classroom", array()), "code", array())))) . "/children/add"), "html", null, true);
        echo "\" class=\"btn btn-primary\">Ajouter une nouvelle classe</a>
\t\t</div>
\t</div>
<div class=\"row\">
\t<table class=\"table mt-2\">
\t\t<thead class=\"thead-light\">
\t\t\t<tr>
\t  \t\t<th scope=\"col\">#</th>
\t  \t\t<th scope=\"col\">Pseudo</th>
\t  \t\t<th scope=\"col\">Avatar</th>
\t  \t\t<th scope=\"col\">Création</th>
\t  \t\t<th scope=\"col\"></th>
\t  \t</tr>
  \t</thead>
  ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["childrens"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["children"]) {
            // line 23
            echo "  \t<tr scope=\"row\">
      <td scope=\"col\">";
            // line 24
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["children"], "id", array()), "html", null, true);
            echo "</td>
      <td scope=\"col\">";
            // line 25
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["children"], "pseudo", array()), "html", null, true);
            echo "</td>
      <td scope=\"col\"><img src=\"";
            // line 26
            echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('url')->getCallable(), array("/assets/img/avatar/")) . twig_get_attribute($this->env, $this->source, $context["children"], "avatar", array())), "html", null, true);
            echo "\" /></td>
      <td scope=\"col\">";
            // line 27
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["children"], "createdAt", array()), "html", null, true);
            echo "</td>
      <td scope=\"col\">
        <a class=\"btn btn-link\" href=\"";
            // line 29
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array(("/backoffice/classroom/edit/" . twig_get_attribute($this->env, $this->source, ($context["classroom"] ?? null), "code", array())))), "html", null, true);
            echo "\">éditer</a>
        <button class=\"btn btn-link deleteButton\" data-href=\"";
            // line 30
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array(("/backoffice/classroom/delete/" . twig_get_attribute($this->env, $this->source, ($context["classroom"] ?? null), "id", array())))), "html", null, true);
            echo "\">supprimer</button>
      </td>
    </tr>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['children'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "\t</table>
</div>
";
    }

    public function getTemplateName()
    {
        return "backoffice/children.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 34,  86 => 30,  82 => 29,  77 => 27,  73 => 26,  69 => 25,  65 => 24,  62 => 23,  58 => 22,  41 => 8,  35 => 4,  32 => 3,  15 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% extends \"backoffice/template.html.twig\" %}
{% block content %}
\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t<h1>Les défis</h1>
\t\t\t<p>Voici la liste des <b>classes</b> déjà existants dans l'application.</p>
\t\t\t<a href=\"{{ url( '/classe/' ~ session.classroom.code ) ~ '/children/add' }}\" class=\"btn btn-primary\">Ajouter une nouvelle classe</a>
\t\t</div>
\t</div>
<div class=\"row\">
\t<table class=\"table mt-2\">
\t\t<thead class=\"thead-light\">
\t\t\t<tr>
\t  \t\t<th scope=\"col\">#</th>
\t  \t\t<th scope=\"col\">Pseudo</th>
\t  \t\t<th scope=\"col\">Avatar</th>
\t  \t\t<th scope=\"col\">Création</th>
\t  \t\t<th scope=\"col\"></th>
\t  \t</tr>
  \t</thead>
  {% for children in childrens %}
  \t<tr scope=\"row\">
      <td scope=\"col\">{{ children.id }}</td>
      <td scope=\"col\">{{ children.pseudo }}</td>
      <td scope=\"col\"><img src=\"{{ url('/assets/img/avatar/') ~ children.avatar }}\" /></td>
      <td scope=\"col\">{{ children.createdAt }}</td>
      <td scope=\"col\">
        <a class=\"btn btn-link\" href=\"{{ url( '/backoffice/classroom/edit/' ~ classroom.code )}}\">éditer</a>
        <button class=\"btn btn-link deleteButton\" data-href=\"{{ url( '/backoffice/classroom/delete/' ~ classroom.id )}}\">supprimer</button>
      </td>
    </tr>
  {% endfor %}
\t</table>
</div>
{% endblock %}", "backoffice/children.html.twig", "I:\\UwAmp-www\\alphacorp\\app\\Views\\backoffice\\children.html.twig");
    }
}
