<?php

/* backoffice/collection/edit.html.twig */
class __TwigTemplate_89c7fc3f7d407dd6121b9955423a4259a2b2749a2c086abcf6bd4c1a2cd44492 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("backoffice/template.html.twig", "backoffice/collection/edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'specific_js' => array($this, 'block_specific_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "backoffice/template.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "BackOffice | les collections";
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "<h1>Editer un abécédaire</h1>
<p>Indiquer les données pour cet abécédaire.</p>
<form action=\"";
        // line 6
        echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('url')->getCallable(), array("/backoffice/collections/edit/")) . twig_get_attribute($this->env, $this->source, ($context["collections"] ?? null), "id", array())), "html", null, true);
        echo "\" method=\"post\">
  <div class=\"form-group row\">
    <label class=\"col-sm-3 col-form-label\">Nom :</label>
    <div class=\"col-sm-8\">
      <input type=\"text\" name=\"name\" required maxlength=\"32\" class=\"form-control\" value=\"";
        // line 10
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["collections"] ?? null), "name", array()), "html", null, true);
        echo "\">
    </div>
  </div>
  <div class=\"form-group row\">
    <div class=\"offset-3\">
      <button class=\"btn btn-secondary\">Enregistrer la nouvelle collection</button>
      <a href=\"";
        // line 16
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array("/backoffice/collections")), "html", null, true);
        echo "\" class=\"btn btn-link\">annuler</a>
    </div>
  </div>
</form>
<div class=\"row\">
  <div class=\"offset-3\">
    <p>Voici l'organisation des lettres pour cet abécédaire.</p>
  </div>
</div>
<div class=\"row\">
  <div class=\"col-2\">
    <h5>Ajouter une LETTRE</h5>
    <form action=\"";
        // line 28
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array(("/backoffice/collections/add-letter/" . twig_get_attribute($this->env, $this->source, ($context["collections"] ?? null), "id", array())))), "html", null, true);
        echo "\" method=\"post\" enctype=\"multipart/form-data\">
      <input type=\"hidden\" name=\"collection_id\" value=\"";
        // line 29
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["collections"] ?? null), "id", array()), "html", null, true);
        echo "\">
      <div class=\"form-group\">
        <label>Lettre</label>
        <select name=\"letter\" class=\"form-control w-50\">
          ";
        // line 33
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, 26));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 34
            echo "          <option>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('chr')->getCallable(), array($context["i"])), "html", null, true);
            echo "</option>
          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "        </select>
      </div>
      <div class=\"custom-file\">
        <input type=\"file\" name=\"image\" class=\"custom-file-input\">
        <label class=\"custom-file-label\">image...</label>
      </div>
      <button class=\"btn btn-primary mt-2\">Ajouter</button>
    </form>
  </div>
  ";
        // line 45
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["collections"] ?? null), "images", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
            // line 46
            echo "  <div class=\"p-4 col-2 border d-flex flex-column justify-content-between align-items-center\">
    <img src=\"";
            // line 47
            echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('url')->getCallable(), array("/assets/img/abécédaire/")) . twig_get_attribute($this->env, $this->source, $context["image"], "image", array())), "html", null, true);
            echo "\"/>
    <p class=\"text-uppercase font-weight-bold\">";
            // line 48
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["image"], "letter", array()), "html", null, true);
            echo "</p>
    <button type=\"button\" class=\"btn btn-primary delete-img\" data-id=\"";
            // line 49
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["image"], "id", array()), "html", null, true);
            echo "\" data-href=\"";
            echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('url')->getCallable(), array("/backoffice/collections/images/delete/")) . twig_get_attribute($this->env, $this->source, $context["image"], "id", array())), "html", null, true);
            echo "\">X</button>
  </div>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        echo "</div>
</div>
";
    }

    // line 55
    public function block_specific_js($context, array $blocks = array())
    {
        // line 56
        echo "<script>
var link = null,
  id = null,
  filename = null;
  // Suppression lettre
\$(\".delete-img\").click(function() {
  id = \$(this).data(\"id\");
  link = \$(this).data(\"href\");
  filename = \$(this).siblings('img').attr('src');
  \$.get(link, {'filename' : filename});
  \$(this).parent().remove();
});
// Affichage lien image
\$(\"[type=file]\").on(\"change\", function(){
  // Name of file and placeholder
  var file = this.files[0].name;
  var dflt = \$(this).attr(\"placeholder\");
  if(\$(this).val()!=\"\"){
    \$(this).next().text(file);
  } else {
    \$(this).next().text(dflt);
  }
});
</script>
";
    }

    public function getTemplateName()
    {
        return "backoffice/collection/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  148 => 56,  145 => 55,  139 => 52,  128 => 49,  124 => 48,  120 => 47,  117 => 46,  113 => 45,  102 => 36,  93 => 34,  89 => 33,  82 => 29,  78 => 28,  63 => 16,  54 => 10,  47 => 6,  43 => 4,  40 => 3,  34 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"backoffice/template.html.twig\" %}
{% block title %}BackOffice | les collections{% endblock %}
{% block content %}
<h1>Editer un abécédaire</h1>
<p>Indiquer les données pour cet abécédaire.</p>
<form action=\"{{ url( '/backoffice/collections/edit/') ~ collections.id }}\" method=\"post\">
  <div class=\"form-group row\">
    <label class=\"col-sm-3 col-form-label\">Nom :</label>
    <div class=\"col-sm-8\">
      <input type=\"text\" name=\"name\" required maxlength=\"32\" class=\"form-control\" value=\"{{ collections.name }}\">
    </div>
  </div>
  <div class=\"form-group row\">
    <div class=\"offset-3\">
      <button class=\"btn btn-secondary\">Enregistrer la nouvelle collection</button>
      <a href=\"{{ url( '/backoffice/collections' )}}\" class=\"btn btn-link\">annuler</a>
    </div>
  </div>
</form>
<div class=\"row\">
  <div class=\"offset-3\">
    <p>Voici l'organisation des lettres pour cet abécédaire.</p>
  </div>
</div>
<div class=\"row\">
  <div class=\"col-2\">
    <h5>Ajouter une LETTRE</h5>
    <form action=\"{{  url(  '/backoffice/collections/add-letter/' ~ collections.id  )}}\" method=\"post\" enctype=\"multipart/form-data\">
      <input type=\"hidden\" name=\"collection_id\" value=\"{{ collections.id }}\">
      <div class=\"form-group\">
        <label>Lettre</label>
        <select name=\"letter\" class=\"form-control w-50\">
          {% for i in 1..26 %}
          <option>{{ chr( i ) }}</option>
          {% endfor %}
        </select>
      </div>
      <div class=\"custom-file\">
        <input type=\"file\" name=\"image\" class=\"custom-file-input\">
        <label class=\"custom-file-label\">image...</label>
      </div>
      <button class=\"btn btn-primary mt-2\">Ajouter</button>
    </form>
  </div>
  {% for image in collections.images %}
  <div class=\"p-4 col-2 border d-flex flex-column justify-content-between align-items-center\">
    <img src=\"{{ url('/assets/img/abécédaire/') ~ image.image }}\"/>
    <p class=\"text-uppercase font-weight-bold\">{{ image.letter }}</p>
    <button type=\"button\" class=\"btn btn-primary delete-img\" data-id=\"{{ image.id }}\" data-href=\"{{ url('/backoffice/collections/images/delete/') ~ image.id }}\">X</button>
  </div>
  {% endfor %}
</div>
</div>
{% endblock %}
{% block specific_js %}
<script>
var link = null,
  id = null,
  filename = null;
  // Suppression lettre
\$(\".delete-img\").click(function() {
  id = \$(this).data(\"id\");
  link = \$(this).data(\"href\");
  filename = \$(this).siblings('img').attr('src');
  \$.get(link, {'filename' : filename});
  \$(this).parent().remove();
});
// Affichage lien image
\$(\"[type=file]\").on(\"change\", function(){
  // Name of file and placeholder
  var file = this.files[0].name;
  var dflt = \$(this).attr(\"placeholder\");
  if(\$(this).val()!=\"\"){
    \$(this).next().text(file);
  } else {
    \$(this).next().text(dflt);
  }
});
</script>
{% endblock %}", "backoffice/collection/edit.html.twig", "I:\\UwAmp-www\\alphacorp\\app\\Views\\backoffice\\collection\\edit.html.twig");
    }
}
