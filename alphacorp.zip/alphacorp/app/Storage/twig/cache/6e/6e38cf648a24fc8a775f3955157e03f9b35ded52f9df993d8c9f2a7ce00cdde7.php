<?php

/* backoffice/classroom/add.html.twig */
class __TwigTemplate_09258d628620cf53923513a2e3d21e950421b680458f321015f856dfc8f520ed extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("backoffice/template.html.twig", "backoffice/classroom/add.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'specific_js' => array($this, 'block_specific_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "backoffice/template.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "BackOffice | les collections";
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "
<h1>Ajouter une classe</h1>
<p>Indiquer les données pour cette classe.</p>
<form action=\"";
        // line 7
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array("/backoffice/classroom/save")), "html", null, true);
        echo "\" method=\"post\">

  <div class=\"form-group row\">
    <label class=\"col-sm-3 col-form-label\">Nom de l'enseignant :</label>
    <div class=\"col-sm-8\">
      <input type=\"text\" name=\"teachername\" required maxlength=\"50\" class=\"form-control\">
    </div>
  </div>
  <div class=\"form-group row\">
    <label class=\"col-sm-3 col-form-label\">Description :</label>
    <div class=\"col-sm-8\">
      <textarea class=\"form-control\" id=\"description\" rows=\"3\" name=\"description\"></textarea>
    </div>
  </div>
  <div class=\"form-group row\">
    <label class=\"col-sm-3 col-form-label\">Code de classe :</label>
    <div class=\"col-sm-6\">
      <input type=\"text\" disabled name=\"code\" id =\"code\" required maxlength=\"32\" class=\"form-control\">
    </div>
    <button id=\"generateCodeBtn\" class=\"col-sm-2 btn btn-primary\" type =\"button\">Générer un code</button>
  </div>

  <div class=\"form-group row\">
    <div class=\"offset-3\">
      <button class=\"btn btn-secondary\">Enregistrer la nouvelle classe</button>
      <a href=\"";
        // line 32
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array("/backoffice/classroom")), "html", null, true);
        echo "\" class=\"btn btn-link\">Annuler</a>
    </div>
  </div>

</form>
";
    }

    // line 38
    public function block_specific_js($context, array $blocks = array())
    {
        // line 39
        echo "<script>
  \$('#generateCodeBtn').click( function() {
    \$.get( \"";
        // line 41
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array("/backoffice/classroom/code")), "html", null, true);
        echo "\" , function( data ) {
      \$('#code').val(data);
    });
  });
  
</script>

";
    }

    public function getTemplateName()
    {
        return "backoffice/classroom/add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 41,  89 => 39,  86 => 38,  76 => 32,  48 => 7,  43 => 4,  40 => 3,  34 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"backoffice/template.html.twig\" %}
{% block title %}BackOffice | les collections{% endblock %}
{% block content %}

<h1>Ajouter une classe</h1>
<p>Indiquer les données pour cette classe.</p>
<form action=\"{{ url( '/backoffice/classroom/save' )}}\" method=\"post\">

  <div class=\"form-group row\">
    <label class=\"col-sm-3 col-form-label\">Nom de l'enseignant :</label>
    <div class=\"col-sm-8\">
      <input type=\"text\" name=\"teachername\" required maxlength=\"50\" class=\"form-control\">
    </div>
  </div>
  <div class=\"form-group row\">
    <label class=\"col-sm-3 col-form-label\">Description :</label>
    <div class=\"col-sm-8\">
      <textarea class=\"form-control\" id=\"description\" rows=\"3\" name=\"description\"></textarea>
    </div>
  </div>
  <div class=\"form-group row\">
    <label class=\"col-sm-3 col-form-label\">Code de classe :</label>
    <div class=\"col-sm-6\">
      <input type=\"text\" disabled name=\"code\" id =\"code\" required maxlength=\"32\" class=\"form-control\">
    </div>
    <button id=\"generateCodeBtn\" class=\"col-sm-2 btn btn-primary\" type =\"button\">Générer un code</button>
  </div>

  <div class=\"form-group row\">
    <div class=\"offset-3\">
      <button class=\"btn btn-secondary\">Enregistrer la nouvelle classe</button>
      <a href=\"{{ url( '/backoffice/classroom' )}}\" class=\"btn btn-link\">Annuler</a>
    </div>
  </div>

</form>
{% endblock %}
{% block specific_js %}
<script>
  \$('#generateCodeBtn').click( function() {
    \$.get( \"{{url( '/backoffice/classroom/code' )}}\" , function( data ) {
      \$('#code').val(data);
    });
  });
  
</script>

{% endblock %}", "backoffice/classroom/add.html.twig", "I:\\UwAmp-www\\alphacorp\\app\\Views\\backoffice\\classroom\\add.html.twig");
    }
}
