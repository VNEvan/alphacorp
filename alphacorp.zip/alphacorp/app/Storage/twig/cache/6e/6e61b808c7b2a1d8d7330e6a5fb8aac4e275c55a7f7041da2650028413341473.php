<?php

/* backoffice/classroom/edit.html.twig */
class __TwigTemplate_0a759c40e40a3c931a03abd430a6a89b27e227ca1e5e121429b8f63ac21684ea extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("backoffice/template.html.twig", "backoffice/classroom/edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'specific_js' => array($this, 'block_specific_js'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "backoffice/template.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "BackOffice | les classes";
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "<h1 class=\"text-center\">Editer une classe</h1>
<p class=\"text-center mb-2\">Indiquer les données pour cette classe.</p>
<form action=\"";
        // line 6
        echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('url')->getCallable(), array("/backoffice/classroom/edit/")) . twig_get_attribute($this->env, $this->source, ($context["classroom"] ?? null), "code", array())), "html", null, true);
        echo "\" method=\"post\">
  <input type=\"hidden\" name=\"id\" value=\"";
        // line 7
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["classroom"] ?? null), "id", array()), "html", null, true);
        echo "\" />
  <div class=\"form-group row\">
    <label class=\"col-sm-3 col-form-label\">Enseignant :</label>
    <div class=\"col-sm-8\">
      <input type=\"text\" name=\"teachername\" maxlength=\"32\" class=\"form-control\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["classroom"] ?? null), "teachername", array()), "html", null, true);
        echo "\">
    </div>
  </div>
  <div class=\"form-group row\">
    <label class=\"col-sm-3 col-form-label\">Description :</label>
    <div class=\"col-sm-8\">
      <textarea class=\"form-control\" id=\"description\" rows=\"3\" name=\"description\">";
        // line 17
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["classroom"] ?? null), "description", array()), "html", null, true);
        echo "</textarea>
    </div>
  </div>
  <div class=\"form-group row\">
    <label class=\"col-sm-3 col-form-label\">Code de classe :</label>
    <div class=\"col-sm-6\">
      <input type=\"text\" disabled name=\"code\" id =\"code\" minlength=\"5\" maxlength=\"32\" class=\"form-control\" value=\"";
        // line 23
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["classroom"] ?? null), "code", array()), "html", null, true);
        echo "\">
    </div>
    <button id=\"generateCodeBtn\" class=\"col-sm-2 btn btn-primary\" type =\"button\">Générer un code</button>
  </div>
  <div class=\"form-group row\">
    <div class=\"offset-3\">
      <button class=\"btn btn-secondary\" type=\"submit\">Mettre à jour les données de la classe</button>
      <a href=\"";
        // line 30
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array("/backoffice/classroom")), "html", null, true);
        echo "\" class=\"btn btn-link\">annuler</a>
    </div>
  </div>
</form>
<div class=\"row\">
  <div class=\"col-8 offset-2 rounded\" style=\"background-color:#f8f9fa\">
    <h1 class=\"text-center\">Ajouter une enfant</h1>
    <form action=\"";
        // line 37
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array(("/backoffice/classroom/add-children/" . twig_get_attribute($this->env, $this->source, ($context["classroom"] ?? null), "id", array())))), "html", null, true);
        echo "\" method=\"post\" enctype=\"multipart/form-data\">
      <input type=\"hidden\" name=\"classroom_code\" value=\"";
        // line 38
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["classroom"] ?? null), "code", array()), "html", null, true);
        echo "\">
      <div class=\"form-group\">
        <label>Pseudo :</label>
        <input type=\"texte\" required name=\"pseudo\" class=\"form-control w-50\">
      </div>
      <div class=\"custom-file\">
        <input type=\"file\" required name=\"avatar\" class=\"custom-file-input\">
        <label class=\"custom-file-label\">avatar...</label>
      </div>
      <button class=\"btn btn-primary mt-2\">Ajouter</button>
    </form>
  </div>
</div>
<div class=\"row\">
  ";
        // line 52
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["childrens"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["children"]) {
            // line 53
            echo "  <div class=\"p-4 col-2 border d-flex flex-column justify-content-between align-items-center\">
    <div class=\"row\">
      <img class=\"w-100 mh-100\" src=\"";
            // line 55
            echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('url')->getCallable(), array("/assets/img/avatar/")) . twig_get_attribute($this->env, $this->source, $context["children"], "avatar", array())), "html", null, true);
            echo "\"/>
    </div>
    <p class=\"text-uppercase font-weight-bold\">";
            // line 57
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["children"], "pseudo", array()), "html", null, true);
            echo "</p>
    <button type=\"button\" class=\"btn btn-primary delete-children\" data-id=\"";
            // line 58
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["children"], "id", array()), "html", null, true);
            echo "\" data-href=\"";
            echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('url')->getCallable(), array("/backoffice/classroom/children/delete/")) . twig_get_attribute($this->env, $this->source, $context["children"], "id", array())), "html", null, true);
            echo "\">Effacer</button>
  </div>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['children'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 61
        echo "</div>

";
    }

    // line 64
    public function block_specific_js($context, array $blocks = array())
    {
        // line 65
        echo "<script>
var link = null,
  id = null;
// Suppression élève
\$(\".delete-children\").click(function() {
  id = \$(this).data(\"id\");
  link = \$(this).data(\"href\");
  console.log(link);
  \$.get(link);
  \$(this).parent().remove();
});
// Génération code classe
\$('#generateCodeBtn').click( function() {
    \$.get( \"";
        // line 78
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('url')->getCallable(), array("/backoffice/classroom/code")), "html", null, true);
        echo "\" , function( data ) {
      \$('#code').val(data);
    });
  });
// Affichage lien image
\$(\"[type=file]\").on(\"change\", function(){
  // Name of file and placeholder
  var file = this.files[0].name;
  var dflt = \$(this).attr(\"placeholder\");
  if(\$(this).val()!=\"\"){
    \$(this).next().text(file);
  } else {
    \$(this).next().text(dflt);
  }
});
  
</script>
";
    }

    public function getTemplateName()
    {
        return "backoffice/classroom/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  169 => 78,  154 => 65,  151 => 64,  145 => 61,  134 => 58,  130 => 57,  125 => 55,  121 => 53,  117 => 52,  100 => 38,  96 => 37,  86 => 30,  76 => 23,  67 => 17,  58 => 11,  51 => 7,  47 => 6,  43 => 4,  40 => 3,  34 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"backoffice/template.html.twig\" %}
{% block title %}BackOffice | les classes{% endblock %}
{% block content %}
<h1 class=\"text-center\">Editer une classe</h1>
<p class=\"text-center mb-2\">Indiquer les données pour cette classe.</p>
<form action=\"{{ url( '/backoffice/classroom/edit/') ~ classroom.code }}\" method=\"post\">
  <input type=\"hidden\" name=\"id\" value=\"{{ classroom.id }}\" />
  <div class=\"form-group row\">
    <label class=\"col-sm-3 col-form-label\">Enseignant :</label>
    <div class=\"col-sm-8\">
      <input type=\"text\" name=\"teachername\" maxlength=\"32\" class=\"form-control\" value=\"{{ classroom.teachername }}\">
    </div>
  </div>
  <div class=\"form-group row\">
    <label class=\"col-sm-3 col-form-label\">Description :</label>
    <div class=\"col-sm-8\">
      <textarea class=\"form-control\" id=\"description\" rows=\"3\" name=\"description\">{{ classroom.description }}</textarea>
    </div>
  </div>
  <div class=\"form-group row\">
    <label class=\"col-sm-3 col-form-label\">Code de classe :</label>
    <div class=\"col-sm-6\">
      <input type=\"text\" disabled name=\"code\" id =\"code\" minlength=\"5\" maxlength=\"32\" class=\"form-control\" value=\"{{ classroom.code }}\">
    </div>
    <button id=\"generateCodeBtn\" class=\"col-sm-2 btn btn-primary\" type =\"button\">Générer un code</button>
  </div>
  <div class=\"form-group row\">
    <div class=\"offset-3\">
      <button class=\"btn btn-secondary\" type=\"submit\">Mettre à jour les données de la classe</button>
      <a href=\"{{ url( '/backoffice/classroom' )}}\" class=\"btn btn-link\">annuler</a>
    </div>
  </div>
</form>
<div class=\"row\">
  <div class=\"col-8 offset-2 rounded\" style=\"background-color:#f8f9fa\">
    <h1 class=\"text-center\">Ajouter une enfant</h1>
    <form action=\"{{  url(  '/backoffice/classroom/add-children/' ~ classroom.id  )}}\" method=\"post\" enctype=\"multipart/form-data\">
      <input type=\"hidden\" name=\"classroom_code\" value=\"{{ classroom.code }}\">
      <div class=\"form-group\">
        <label>Pseudo :</label>
        <input type=\"texte\" required name=\"pseudo\" class=\"form-control w-50\">
      </div>
      <div class=\"custom-file\">
        <input type=\"file\" required name=\"avatar\" class=\"custom-file-input\">
        <label class=\"custom-file-label\">avatar...</label>
      </div>
      <button class=\"btn btn-primary mt-2\">Ajouter</button>
    </form>
  </div>
</div>
<div class=\"row\">
  {% for children in childrens %}
  <div class=\"p-4 col-2 border d-flex flex-column justify-content-between align-items-center\">
    <div class=\"row\">
      <img class=\"w-100 mh-100\" src=\"{{ url('/assets/img/avatar/') ~ children.avatar }}\"/>
    </div>
    <p class=\"text-uppercase font-weight-bold\">{{ children.pseudo }}</p>
    <button type=\"button\" class=\"btn btn-primary delete-children\" data-id=\"{{ children.id }}\" data-href=\"{{ url('/backoffice/classroom/children/delete/') ~ children.id }}\">Effacer</button>
  </div>
  {% endfor %}
</div>

{% endblock %}
{% block specific_js %}
<script>
var link = null,
  id = null;
// Suppression élève
\$(\".delete-children\").click(function() {
  id = \$(this).data(\"id\");
  link = \$(this).data(\"href\");
  console.log(link);
  \$.get(link);
  \$(this).parent().remove();
});
// Génération code classe
\$('#generateCodeBtn').click( function() {
    \$.get( \"{{url( '/backoffice/classroom/code' )}}\" , function( data ) {
      \$('#code').val(data);
    });
  });
// Affichage lien image
\$(\"[type=file]\").on(\"change\", function(){
  // Name of file and placeholder
  var file = this.files[0].name;
  var dflt = \$(this).attr(\"placeholder\");
  if(\$(this).val()!=\"\"){
    \$(this).next().text(file);
  } else {
    \$(this).next().text(dflt);
  }
});
  
</script>
{% endblock %}", "backoffice/classroom/edit.html.twig", "I:\\UwAmp-www\\alphacorp\\app\\Views\\backoffice\\classroom\\edit.html.twig");
    }
}
